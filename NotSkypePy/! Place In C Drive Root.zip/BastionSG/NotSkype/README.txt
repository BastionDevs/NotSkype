NotSkype README

Do ensure that you have python.exe added to %PATH%
Please install the following Python packages via pip:
requests
Flask
skpy
simplejson